package com.expensetracker.ui;

import com.expensetracker.model.Expense;
import com.expensetracker.model.User;
import com.expensetracker.service.CategoryService;
import com.expensetracker.service.ExpenseService;
import com.expensetracker.service.UserService;
import java.util.List;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static UserService userService = new UserService();
    static ExpenseService expenseService = new ExpenseService();
    static CategoryService categoryService = new CategoryService();
    static User loggedInUser = null;

    public static void main(String[] args) {
        System.out.println("=== Smart Expense Tracker ===");
        while (true) {
            if (loggedInUser == null) {
                showAuthMenu();
            } else {
                showMainMenu();
            }
        }
    }

    static void showAuthMenu() {
        System.out.println("\n1. Register\n2. Login\n3. Exit");
        System.out.print("Choose: ");
        int choice = sc.nextInt(); sc.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Username: "); String u = sc.nextLine();
                System.out.print("Password: "); String p = sc.nextLine();
                System.out.print("Email: ");    String e = sc.nextLine();
                System.out.println(userService.register(u, p, e)
                    ? "✅ Registered!" : "❌ Failed!");
                break;
            case 2:
                System.out.print("Username: "); String lu = sc.nextLine();
                System.out.print("Password: "); String lp = sc.nextLine();
                loggedInUser = userService.login(lu, lp);
                System.out.println(loggedInUser != null
                    ? "✅ Welcome " + loggedInUser.getUsername() : "❌ Invalid credentials!");
                break;
            case 3:
                System.exit(0);
        }
    }

    static void showMainMenu() {
        System.out.println("\n1. Add Expense\n2. View Expenses\n3. Delete Expense\n4. Logout");
        System.out.print("Choose: ");
        int choice = sc.nextInt(); sc.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Category ID: ");  int cId = sc.nextInt(); sc.nextLine();
                System.out.print("Description: ");  String desc = sc.nextLine();
                System.out.print("Amount: ");        double amt = sc.nextDouble(); sc.nextLine();
                System.out.println(expenseService.addExpense(loggedInUser.getId(), cId, desc, amt)
                    ? "✅ Expense Added!" : "❌ Failed!");
                break;
            case 2:
                List<Expense> expenses = expenseService.getExpenses(loggedInUser.getId());
                if (expenses.isEmpty()) {
                    System.out.println("No expenses found.");
                } else {
                    System.out.println("\nID | Category | Description | Amount | Date");
                    for (Expense ex : expenses) {
                        System.out.println(ex.getId() + " | " + ex.getCategoryId()
                            + " | " + ex.getDescription()
                            + " | ₹" + ex.getAmount()
                            + " | " + ex.getDate());
                    }
                }
                break;
            case 3:
                System.out.print("Expense ID to delete: "); int delId = sc.nextInt();
                System.out.println(expenseService.deleteExpense(delId)
                    ? "✅ Deleted!" : "❌ Failed!");
                break;
            case 4:
                loggedInUser = null;
                System.out.println("Logged out.");
                break;
        }
    }
}