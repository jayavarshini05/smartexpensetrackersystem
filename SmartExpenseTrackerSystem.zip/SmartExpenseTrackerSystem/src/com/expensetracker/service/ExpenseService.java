package com.expensetracker.service;

import com.expensetracker.dao.ExpenseDAO;
import com.expensetracker.model.Expense;
import java.util.Date;
import java.util.List;

public class ExpenseService {
    private ExpenseDAO expenseDAO = new ExpenseDAO();

    public boolean addExpense(int userId, int categoryId, String description, double amount) {
        Expense expense = new Expense(0, userId, categoryId, description, amount, new Date());
        return expenseDAO.addExpense(expense);
    }

    public List<Expense> getExpenses(int userId) {
        return expenseDAO.getExpensesByUser(userId);
    }

    public boolean deleteExpense(int id) {
        return expenseDAO.deleteExpense(id);
    }
}