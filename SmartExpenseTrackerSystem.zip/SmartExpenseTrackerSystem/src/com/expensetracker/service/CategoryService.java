package com.expensetracker.service;

import com.expensetracker.dao.CategoryDAO;
import com.expensetracker.model.Category;
import java.util.List;

public class CategoryService {
    private CategoryDAO categoryDAO = new CategoryDAO();

    public boolean addCategory(String name) {
        Category category = new Category(0, name);
        return categoryDAO.addCategory(category);
    }

    public List<Category> getAllCategories() {
        return categoryDAO.getAllCategories();
    }
}