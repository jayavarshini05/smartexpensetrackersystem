package com.expensetracker.service;

import com.expensetracker.dao.UserDAO;
import com.expensetracker.model.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    public boolean register(String username, String password, String email) {
        User user = new User(0, username, password, email);
        return userDAO.registerUser(user);
    }

    public User login(String username, String password) {
        return userDAO.loginUser(username, password);
    }
}